package src.mua.Support;

import java.util.Scanner;

public class ScannerControl {
    private static Scanner scan;

    public ScannerControl() {
    }

    static public void newScanner(Scanner scanner) {
        scan = scanner;
    }
    static public boolean scanHasNextLine() {
        return scan.hasNext();
    }
    static public String scanNextLine() {
        return scan.nextLine();
    }

}