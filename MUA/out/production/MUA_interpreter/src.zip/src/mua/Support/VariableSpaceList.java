package src.mua.Support;

import src.mua.Basic.BasicElement;
import src.mua.TYPE.NUM;

import java.util.ArrayList;

public class VariableSpaceList {
    private ArrayList<Variable> varList;

    public VariableSpaceList() {
        varList = new ArrayList<>();
    }
    public void addNewVarList(Variable var) {
        varList.add(new Variable(var));
    }
    public Variable getVarList() {
        return varList.get(varList.size() - 1);
    }

    public Variable getVarList4varName(String varName) {
        if(varName.equals("pi")) {
            try {
                varList.get(varList.size() - 1).makeVar("pi", new NUM("3.14159"));
            } catch (Exception e) {

            }
            return varList.get(varList.size() - 1);
        }

        Variable var = varList.get(varList.size() - 1);
        try {
            while (var.hasVar(varName)) {
                var = var.getParentVar();
            }
            return var;
        } catch (Exception e) {
            return null;
        }
    }

    public BasicElement getVarValue(String varName) {
        Variable var = getVarList4varName(varName);
        try {
            return var.getVar(varName);
        }catch (Exception e) {
            return null;
        }
    }
    public void makeVarValue(String name, BasicElement value) {
        varList.get(varList.size() - 1).makeVar(name, value);
    }
    public void eraseVar(String varName) {
        Variable var = varList.get(varList.size() - 1);
        while(var.hasVar(varName)) {
            var = var.getParentVar();
            if(var == null) return;
        }
        var.eraseVar(varName);
    }
    public void eraseAllVar() {
        varList.get(varList.size() - 1).erall();
    }
    public boolean hasVar(String varName) {
        Variable var = varList.get(varList.size() - 1);
        while(var.hasVar(varName)) {
            var = var.getParentVar();
            if(var == null) return false;
        }
        return true;
    }
    public void export(String name) {
        if(varList.size() == 1) return;
        Variable var = varList.get(varList.size() - 1);
        varList.get(0).makeVar(name, getVarValue(name));
    }

    public BasicElement getReturnVal() {
        return varList.get(varList.size() - 1).returnVal;
    }
    public void setReturnVal(BasicElement element) {
        varList.get(varList.size() - 1).returnVal = element;
    }
    public void deleteVarSpace() {
        //varList.get(varList.size() - 1).clearVarMap();
        varList.remove(varList.size() - 1);
    }

}
