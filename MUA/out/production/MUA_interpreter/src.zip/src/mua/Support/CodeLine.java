package src.mua.Support;

import src.mua.Basic.BasicElement;
import src.mua.Operation.Add;
import src.mua.TYPE.*;
import src.mua.Exception.*;

import java.util.ArrayList;
import java.util.Arrays;

public class CodeLine {

    static public String addBlank(String Code) {
        StringBuilder codeContentBuilder = new StringBuilder(Code);
        preBlank(codeContentBuilder);
        return codeContentBuilder.toString();
    }

    public static void preBlank(StringBuilder codeContentBuilder) {
        for(int i = 0; i < codeContentBuilder.length();) {
            if (codeContentBuilder.charAt(i) == '[' || codeContentBuilder.charAt(i) == ']') {
                codeContentBuilder.insert(i, ' ');
                codeContentBuilder.insert(i + 2, ' ');
                i = i + 2;
            }
            else i++;
        }
    }

    static public ArrayList<BasicElement> changeStr2MuaELe(ArrayList<String> strList)  {
        ArrayList<BasicElement> eleList = new ArrayList<>();
        for(int i = 0; i < strList.size(); i++) {
            String str = strList.get(i);
            if(str.length() >= 2 && str.substring(0, 2).equals("//")) {
                break;
            }
            try {
                eleList.add(new NUM(str));
            } catch (NumFormatException NFE) {
                if(str.charAt(0) == '"')
                    eleList.add(new WORD(str.substring(1)));
                else if(str.equals("false") || str.equals("true"))
                    eleList.add(new BOOL(str));
//                else if(str.equals("+"))
//                    eleList.add(new Optor("add"));
//                else if(str.equals("-"))
//                    eleList.add(new Optor("sub"));
//                else if(str.equals("*"))
//                    eleList.add(new Optor("mul"));
//                else if(str.equals("/"))
//                    eleList.add(new Optor("div"));
//                else if(str.equals("%"))
//                    eleList.add(new Optor("mod"));
                else if(str.charAt(0) == ':') {
                    eleList.add(new Optor("thing"));
                    eleList.add(new WORD(str.substring(1)));
                } else if(str.equals("[") || str.charAt(0) == '[') {
                    int bracket = 0;
                    StringBuilder strChange2List = new StringBuilder();
                    while(true) {
                        if(i >= strList.size()) {
                            String res = ScannerControl.scanNextLine();
                            strList = new ArrayList<>(Arrays.asList(res.split("\\s+")));
                            strList.remove("");
                            i = 0;
                        }
                        str = strList.get(i);
                        for(int t = 0; t < str.length(); t++) {
                            if(str.charAt(t) == '[')
                                bracket++;
                            else break;
                        }
                        for(int t = str.length() - 1; t >= 0; t--) {
                            if(str.charAt(t) == ']')
                                bracket--;
                            else break;
                        }
                        strChange2List.append(str).append(" ");
                        if(bracket == 0)
                            break;
                        i++;
                    }
                    while(strChange2List.charAt(strChange2List.length() - 1) == ' ') {
                        strChange2List.delete(strChange2List.length() - 1, strChange2List.length());
                    }
//                    System.out.println(strChange2List.toString());
                    eleList.add(new LIST(strChange2List.toString()));
                }
                else if(str.equals("(") || str.charAt(0) == '(')  {
                    int bracket = 0;
                    StringBuilder strChange2List = new StringBuilder();
                    while(true) {
                        if(i >= strList.size()) {
                            String res = ScannerControl.scanNextLine();
                            strList = new ArrayList<>(Arrays.asList(res.split("\\s+")));
                            strList.remove("");
                            i = 0;
                        }
                        str = strList.get(i);
                        for(int t = 0; t < str.length(); t++) {
                            if(str.charAt(t) == '(')
                                bracket++;
                            else break;
                        }
                        for(int t = str.length() - 1; t >= 0; t--) {
                            if(str.charAt(t) == ')')
                                bracket--;
                            else break;
                        }
                        strChange2List.append(str).append(" ");
                        if(bracket == 0)
                            break;
                        i++;
                    }
                    while(strChange2List.charAt(strChange2List.length() - 1) == ' ') {
                        strChange2List.delete(strChange2List.length() - 1, strChange2List.length());
                    }
                    strChange2List.delete(0, 1);
                    strChange2List.delete(strChange2List.length() - 1, strChange2List.length());
//                    System.out.println(strChange2List.toString());
                    eleList.add(new Expression(strChange2List.toString()));
                }
                else {
                    eleList.add(new Optor(str));
                }
            }
        }
        return eleList;
    }
}
