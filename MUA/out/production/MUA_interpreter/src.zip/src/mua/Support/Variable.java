package src.mua.Support;

import src.mua.Basic.BasicElement;
import src.mua.TYPE.NUM;

import java.util.ArrayList;
import java.util.HashMap;

public class Variable {
    HashMap<String, BasicElement> varMap;
    private Variable parentVar;
    BasicElement returnVal;
    public Variable(Variable parent) {
        varMap = new HashMap<String, BasicElement>();
        this.parentVar = parent;
        returnVal = null;
    }
    public Variable getParentVar() {
        return parentVar;
    }

    public void makeVar(String name, BasicElement value) {
        varMap.put(name, value);
    }

    public boolean hasVar(String var) {
        return !varMap.containsKey(var);
   }

    public BasicElement getVar(String var) {
        if(var.equals("pi")) {
            try {
                makeVar("pi", new NUM("3.14159"));
            } catch (Exception e) {

            }
        }
        return varMap.get(var);
   }


    public ArrayList<String> getVarNames() {
        return new ArrayList<>(varMap.keySet());
   }
    /**
     * 需不需要Exception呢？
     * @param var
     * @return
     */
    public boolean eraseVar(String var) {
        if(varMap.containsKey(var)) {
            varMap.remove(var);
            return true;
        } else return false;
    }
    public void erall() {
        varMap.clear();
    }
    public void setReturnVal(BasicElement RVal) {
        returnVal = RVal;
    }
    public void clearVarMap() {
        varMap.clear();
    }
    public void printVarList() {
        System.out.println(varMap.keySet());
    }
}
