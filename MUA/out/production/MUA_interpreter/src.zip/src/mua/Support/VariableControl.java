package src.mua.Support;

public class VariableControl {
    static private VariableSpaceList VarSL;
    public VariableControl() { }
    static public void newVarSL(VariableSpaceList initialVarSL) {
        VarSL = initialVarSL;
    }
    static public VariableSpaceList getVarSL() {
        return VarSL;
    }
}
