package src.mua.Basic;

import src.mua.Exception.OperandOverflowException;

import java.util.ArrayList;

public abstract class BasicOperation implements Foundation{
    public int operandNeedCount;
    public ArrayList<BasicElement> BasicList;

    /**
     * initialize Operation
     */
    public BasicOperation() {
        BasicList = new ArrayList<>();
    }

    /**
     * add operands to the Operation
     * BasicList is the operandsList
     * @param addOperand
     * @throws OperandOverflowException
     */
    public void addOperand(Foundation addOperand) throws OperandOverflowException{
        if(BasicList.size() >= operandNeedCount)
            throw new OperandOverflowException(operandNeedCount);
        BasicList.add(addOperand.exeResult());
    }

    /**
     * operand are ready and the operation can be executed
     * @return
     */
    public boolean ready2exe() {return BasicList.size() == operandNeedCount;}

    /**
     * executing the operation and return the result
     * @return
     */
    public abstract BasicElement exeResult();

    public int ElementType() { return 0; }
}
