package src.mua.Basic;
import java.lang.Exception;

public class BasicException extends Exception {
    protected BasicException() {
        //System.out.println(exceptionMessage);
    }
}
