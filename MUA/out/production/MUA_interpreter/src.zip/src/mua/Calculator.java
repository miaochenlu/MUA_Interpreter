// package src.mua;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Stack;

public class Calculator {
    String expression;
    String operands = "+-*/%()";

    Calculator(String expr) {
        expression = expr;
    }

    static int judgePriority(String operator) {
        int priority = -1;
        switch(operator) {
            case "+":
            case "-": priority = 1; break;
            case "*":
            case "/":
            case "%": priority = 2; break;
            case "(": priority = 0; break;
            case ")": priority = 0; break;
            default : priority = -1;
        }
        return priority;
    }

    double calculation(Stack<Double> operandStack, String operator) {
        double result = 0;
        double a = operandStack.pop();
        double b = operandStack.pop();
        switch(operator) {
            case "*": result = b * a; break;
            case "/": result = b / a; break;
            case "%": result = b % a; break;
            case "+": result = b + a; break;
            case "-": result = b - a; break;
        }
        return result;
    }


    public void preDeal() {
        String res1 = new String();
        for(int i = 0; i < expression.length();i++) {
            String substr = expression.substring(i, i + 1);
            if(operands.contains(substr))
                res1 = res1 + " " + substr + " ";
            else if(!substr.equals(" "))
                res1 += substr;
        }
        expression = res1;

        String res2 = new String();
        int minusAttention = 0;
        Scanner strScan = new Scanner(expression);

        //deal with pre '-'
        while(strScan.hasNext()) {
            String readstr = strScan.next();
            if(readstr.equals("-") && minusAttention == 0)
                res2 += "0 ";
            else if(readstr.equals("("))
                minusAttention = -1;

            minusAttention++;
            res2 = res2 + readstr + " ";
        }
        expression = res2;
//        System.out.println(expression);
    }

    public double calculate() {
        preDeal();
        Stack<String> operatorStack = new Stack();
        Stack<Double> operandStack = new Stack();
        Scanner exprScan = new Scanner(expression);
        double result = 0;

        while(exprScan.hasNext()) {
            String readstr = exprScan.next();
            if(operands.contains(readstr)) {
                //operator stack empty OR operator has higher priority
                if(readstr.equals("(")) {
                    operatorStack.push(readstr);
                } else if(readstr.equals(")")){
                    while(!operatorStack.peek().equals("(")) {
                        result = calculation(operandStack, operatorStack.pop());
                        operandStack.push(result);
                    }
                    operatorStack.pop();
                } else if(operatorStack.empty() || judgePriority(readstr) > judgePriority(operatorStack.peek()) )
                    operatorStack.push(readstr);
                else {
                    while(!operatorStack.empty() && judgePriority(readstr) <= judgePriority(operatorStack.peek())) {
                        result = calculation(operandStack, operatorStack.pop());
                        operandStack.push(result);
                    }
                    operatorStack.push(readstr);
                }
            } else {
                operandStack.push(Double.valueOf(readstr));
            }
        }
        exprScan.close();

        while(!operatorStack.empty()) {
            result = calculation(operandStack, operatorStack.pop());
            operandStack.push(result);
        }

        return operandStack.pop();
    }

    public static void main(String args[]) {
        Scanner scan = new Scanner(System.in);
        String expr = scan.nextLine();
        scan.close();
        Calculator cal = new Calculator(expr);
//        System.out.println(cal.calculate());
    }
}