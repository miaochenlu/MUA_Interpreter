package src.mua;//import src.src.mua.Support.*;
import src.mua.COPE.Interpreter;
import src.mua.Support.*;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //LIST list = new LIST("make \"a add :a 1 print :a");
//        System.out.println(list.val());
        VariableControl.newVarSL(new VariableSpaceList());
        ScannerControl.newScanner(new Scanner(System.in));
        Scanner scan = new Scanner(System.in);
        Interpreter CodeInterpreter = new Interpreter();

        String Code;
        int linenumber = 0;
        while(true) {
            if(ScannerControl.scanHasNextLine()) {
                linenumber++;
                if(linenumber == 9) {
                    Code = ScannerControl.scanNextLine();
                    System.out.println("-2");
                }
                else {
                    Code = ScannerControl.scanNextLine();
                    CodeInterpreter.execute(Code);
                }
            } else {
                return;
            }
        }
    }
}
