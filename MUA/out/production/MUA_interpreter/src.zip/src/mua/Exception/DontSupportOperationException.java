package src.mua.Exception;
import src.mua.Basic.BasicException;
public class DontSupportOperationException extends BasicException{
    public DontSupportOperationException() {
//        System.out.println("Don't support such operation, please check your code.\n");
    }
}
