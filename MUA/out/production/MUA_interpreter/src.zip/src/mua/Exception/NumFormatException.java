package src.mua.Exception;
import src.mua.Basic.BasicException;
public class NumFormatException extends BasicException{
    public NumFormatException(String val) {
        //System.out.println(val + " is not a number\n");
    }
}
