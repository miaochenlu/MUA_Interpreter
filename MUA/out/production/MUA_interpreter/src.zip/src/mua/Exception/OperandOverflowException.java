package src.mua.Exception;
import src.mua.Basic.*;
//import src.src.mua.Exception.*;
import src.mua.Exception.*;
import src.mua.TYPE.NUM;

public class OperandOverflowException extends BasicException {
    public OperandOverflowException(int operandNeedCount) {
//        System.out.println("Too much operands, only need " + operandNeedCount + " operands");
    }
}
