package src.mua.COPE;

import src.mua.Basic.BasicElement;

import java.util.ArrayList;

import src.mua.Basic.BasicOperation;
//import src.src.mua.Operation.*;
//import src.src.mua.Exception.*;
import src.mua.Basic.Foundation;
import src.mua.Operation.*;
import src.mua.Exception.*;
import src.mua.TYPE.*;
import src.mua.Support.*;

public class Executor {
    OpHelper OPH = new OpHelper();
    ArrayList<Foundation> OperationList;

    public Executor() {
        OperationList = new ArrayList<>();
    }

    public void execute2(ArrayList<BasicElement> elementList) {
        while (elementList.size() > 0) {
            BasicOperation newOp = null;
            int size = elementList.size();
            int j = 0;
            for (j = size - 1; j >= 0; j--) {
                if (elementList.get(j).elementType() == 0) {
                    //operation instance
                    newOp = OPH.getOptor(elementList.get(j).val());
                    break;
                }
            }
            if (newOp != null) {
                //如果是一个operation,将operandNeedCount数量的操作数压栈
                int s = j + newOp.operandNeedCount;
                while (s > j) {
                    try {
                        newOp.addOperand(elementList.get(s));
                        elementList.remove(s);
                        s--;
                    } catch (OperandOverflowException OPFLOW) {
//
                    }
                }
                BasicElement res = newOp.exeResult();

                if (res != null)
                    elementList.set(j, res);
                else {
                    elementList.remove(j);
                    if (elementList.size() != 0) {
                        System.out.print("ERROR");
                        return;
                    }
                }
            } else {
                if (elementList.size() == 1) {
//                    System.out.println(elementList.get(0).val());
                } else
                    System.out.println("ERROR");
                return;
            }
        }
    }

    private void mergeOperand(ArrayList<Foundation> operationList) {
        try {
            while (operationList.size() > 1 && operationList.get(operationList.size() - 1).ready2exe()) {
                Foundation element = operationList.remove(operationList.size() - 1);
                try {
                    operationList.get(operationList.size() - 1).addOperand(element);
                } catch (DontSupportOperationException | OperandOverflowException ignored) {

                }
            }
        }catch (Exception e) {

        }
    }

    public ArrayList<BasicElement> execute(ArrayList<BasicElement> elementList) {
        try {
            return executeCode(elementList, OperationList);
        } catch (Exception e) {
            return null;
        }
    }


    public void executeList(LIST list) {
        ArrayList<BasicElement> elementList = list.ListElement();
        ArrayList<Foundation> OperationList = new ArrayList<>();
        executeCode(elementList, OperationList);
    }

    /**
     * execute the code
     * @param elementList
     * @param operationList
     */
    private ArrayList<BasicElement> executeCode(ArrayList<BasicElement> elementList, ArrayList<Foundation> operationList) {
        int i = 0;
        ArrayList<BasicElement> result = new ArrayList<BasicElement>();
        boolean stopSignal = false;
        while (i < elementList.size()) {
            if (elementList.get(i).elementType() == 0) {                            //if this element is an operation
                if (OpHelper.isOperation(elementList.get(i).val()))                  //default function
                    operationList.add(OPH.getOptor(elementList.get(i).val()));
                else                                                                //user-defined function
                    operationList.add(OPH.getFunctor(elementList.get(i).val()));
            }
            else if(elementList.get(i) instanceof Expression)
                operationList.add(((Expression) elementList.get(i)).ExpreVal());
            else operationList.add(elementList.get(i));                           //Basic Element

            if (operationList.get(operationList.size() - 1) instanceof Stop) {      //Stop function
                stopSignal = true;
            }

            mergeOperand(operationList);
            if (operationList.size() == 1 && operationList.get(0).ready2exe()) {
                result.add(operationList.remove(0).exeResult());
                if (stopSignal) break;
            }
            i++;
        }
        return result;
    }

    public BasicElement calculate(ArrayList<String>stringList) {
        String operandsPriority1 = "+-";
        String operandsPriority2 = "*/%";
        int bracket = 0;
        int i = 0;
        int pos = -1;
        for(i = stringList.size() - 1; i >= 0; i--) {
            if(stringList.get(i).equals("(")) bracket++;
            else if(stringList.get(i).equals(")")) bracket--;
            else if(bracket == 0) {
                pos = operandsPriority1.indexOf(stringList.get(i));
                if(pos >= 0) break;
            }

        }
        if(pos < 0) {
            for(i = stringList.size() - 1; i >= 0; i--) {
                if(stringList.get(i).equals("(")) bracket++;
                else if(stringList.get(i).equals(")")) bracket--;
                else if(bracket == 0) {
                    pos = operandsPriority2.indexOf(stringList.get(i));
                    if(pos >= 0) break;
                }
            }
        }
        if(pos >= 0) {
//            System.out.println(stringList.get(i));
            BasicOperation op = OPH.getExprOptor(stringList.get(i));
            ArrayList<String> leftlist = new ArrayList<>();
            ArrayList<String> rightlist = new ArrayList<>();
            for(int j = 0; j < i; j++) leftlist.add(stringList.get(j));
            for(int j = i + 1; j < stringList.size(); j++) rightlist.add(stringList.get(j));
            try {
                op.addOperand(calculate(leftlist));
            } catch (Exception e) {

            }
            try {
                op.addOperand(calculate(rightlist));
            }catch (Exception e) {

            }
            try {
                return op.exeResult();
            } catch (Exception e) {
                return null;
            }
        }

        Executor executor = new Executor();
        ArrayList<BasicElement> elementList = CodeLine.changeStr2MuaELe(stringList);
        ArrayList<BasicElement> res = executor.execute(elementList);
        if(res.size() >= 0) return res.get(0);
        else return null;
    }
}
