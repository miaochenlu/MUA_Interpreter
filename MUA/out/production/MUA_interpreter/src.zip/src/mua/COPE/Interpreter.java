package src.mua.COPE;

import java.util.ArrayList;

//import src.src.mua.Basic.*;
//import src.src.mua.Exception.*;
import src.mua.Basic.*;
import src.mua.Exception.*;
import src.mua.COPE.*;
import src.mua.Support.VariableControl;

public class Interpreter {
    private String Code;
    private Splitor codeSplit;
    private Executor codeExecutor;

    public Interpreter() {
        codeSplit = new Splitor();
        codeExecutor = new Executor();
        VariableControl.getVarSL().addNewVarList(null);
    }

    /**
     * execute code
     */
    public void execute(String Code) {
        //first step: split one line code
        this.Code = new String(Code);
        ArrayList<BasicElement> elementList = new ArrayList<BasicElement>();
        try {
            elementList = new ArrayList<BasicElement>(codeSplit.codeSplit(Code));
            codeExecutor.execute(elementList);
        } catch (Exception e) {
//            System.out.println("ERROR: ");
        }
    }

}
