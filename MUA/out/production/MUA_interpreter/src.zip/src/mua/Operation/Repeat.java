package src.mua.Operation;

import src.mua.Basic.BasicElement;
import src.mua.Basic.BasicOperation;
import src.mua.COPE.Executor;
import src.mua.TYPE.LIST;

public class Repeat extends BasicOperation {
    public Repeat() {
        operandNeedCount = 2;
    }
    @Override
    public int elementType() {
        return 0;
    }

    @Override
    public BasicElement exeResult() {
        double op1 = Double.valueOf(BasicList.get(0).val()).intValue();
        LIST op2 = (LIST) BasicList.get(1);
        Executor executor = new Executor();
        for(int i = 0; i < op1; i++) {
            executor.executeList(op2);
        }
        return null;
    }
}
