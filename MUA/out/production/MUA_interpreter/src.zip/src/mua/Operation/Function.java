package src.mua.Operation;

import src.mua.Basic.BasicElement;
import src.mua.Basic.BasicOperation;
import src.mua.COPE.Executor;
import src.mua.Support.Variable;
import src.mua.Support.VariableControl;
import src.mua.TYPE.LIST;

public class Function extends BasicOperation {
    private String funcName;
    private LIST args;
    private LIST codes;
    public Function(String FuncName, LIST L) {
        funcName = FuncName;
        try {
            args = (LIST) L.getListElement(0);
            codes = (LIST) L.getListElement(1);
            operandNeedCount = args.LISTSize();
        }catch (Exception e) {
            args = null;
            codes = null;
            operandNeedCount = 0;
        }
    }

    @Override
    public int elementType() {
        return 0;
    }

    @Override
    public BasicElement exeResult() {
        VariableControl.getVarSL().addNewVarList((VariableControl.getVarSL().getVarList4varName(funcName)));
        for(int i = 0; i < operandNeedCount; i++) {
            VariableControl.getVarSL().makeVarValue(args.getListElement(i).val(), BasicList.get(i));
        }
        Executor codeExecutor = new Executor();
//        System.out.println(codes.val());
        codeExecutor.executeList(codes);
        BasicElement returnVal = VariableControl.getVarSL().getReturnVal();
        VariableControl.getVarSL().deleteVarSpace();
        return returnVal;
    }
}
