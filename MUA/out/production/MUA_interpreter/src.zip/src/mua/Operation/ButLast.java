package src.mua.Operation;

import src.mua.Basic.BasicElement;
import src.mua.Basic.BasicOperation;
import src.mua.TYPE.LIST;
import src.mua.TYPE.WORD;

public class ButLast extends BasicOperation {
    public ButLast()  {
        operandNeedCount = 1;
    }

    @Override
    public int elementType() {
        return 0;
    }

    @Override
    public BasicElement exeResult() {
        BasicElement op1 = BasicList.get(0);
        if(op1 instanceof LIST) {
            String res = new String();
            res += "[";
            for(int i = 0; i < ((LIST) op1).LISTSize() - 1; i++) {
                if(((LIST) op1).getListElement(i) instanceof LIST)
                    res += "[" + ((LIST) op1).getListElement(i).val() + "]";
                else
                    res += ((LIST) op1).getListElement(i).val();
                if(i != ((LIST) op1).LISTSize() - 2)
                    res += " ";
            }
            res += "]";
//            System.out.println("here" + res);
            return new LIST(res);
        }
        else {
            StringBuilder res = new StringBuilder(op1.val());
            res.delete(res.length() - 1, res.length());
//            return new WORD(String.valueOf(op1.val().charAt(0)));
            return new WORD(res.toString());
        }
    }
}
