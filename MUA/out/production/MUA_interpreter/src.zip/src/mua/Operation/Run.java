package src.mua.Operation;

import src.mua.Basic.BasicElement;
import src.mua.Basic.BasicOperation;
import src.mua.COPE.Executor;
import src.mua.TYPE.LIST;

public class Run extends BasicOperation {
    public Run() {
        operandNeedCount = 1;
    }
    @Override
    public int elementType() {
        return 0;
    }

    @Override
    public BasicElement exeResult() {
        LIST op1 = (LIST) BasicList.get(0);
        Executor executor = new Executor();
        executor.executeList(op1);
        return null;
    }
}
