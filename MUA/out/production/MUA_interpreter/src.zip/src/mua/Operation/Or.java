package src.mua.Operation;

public class Or {
}
