package src.mua.Operation;

import src.mua.Basic.BasicElement;
import src.mua.Basic.BasicOperation;
import src.mua.TYPE.LIST;

public class MergeList extends BasicOperation {
    public MergeList() {
        operandNeedCount = 2;
    }

    @Override
    public int elementType() {
        return 0;
    }

    @Override
    public BasicElement exeResult() {
        try {
            BasicElement op1 = BasicList.get(0);
            BasicElement op2 = BasicList.get(1);
            String res = new String();
            res = "[";
            if (op1 instanceof LIST)
                res = res + ((LIST) op1).valWithbracket();
            else
                res = res + op1.val();

            res += " ";

            if (op2 instanceof LIST)
                res = res + ((LIST) op2).valWithbracket();
            else
                res = res + op2.val();
            res += "]";

            LIST list = new LIST(res);
            return list;
        }catch (Exception e) {
            return null;
        }
    }
}
