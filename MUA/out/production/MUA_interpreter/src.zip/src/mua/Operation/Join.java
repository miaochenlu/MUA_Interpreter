package src.mua.Operation;

import src.mua.Basic.BasicElement;
import src.mua.Basic.BasicOperation;
import src.mua.TYPE.LIST;


public class Join extends BasicOperation {
    public Join() {
        operandNeedCount = 2;
    }

    @Override
    public int elementType() {
        return 0;
    }

    @Override
    public BasicElement exeResult() {
        try {
            LIST op1 = (LIST) BasicList.get(0);
            BasicElement op2 = BasicList.get(1);

            String res = new String();
            res = "[";
            if (op1.LISTSize() != 0) {
                res += op1.val();
                res += " ";
            }

            if (op2 instanceof LIST)
                res = res + ((LIST) op2).valWithbracket();
            else
                res = res + op2.val();
            res += "]";

            LIST list = new LIST(res);
            return list;
        }catch (Exception e) {
            return null;
        }
    }
}
