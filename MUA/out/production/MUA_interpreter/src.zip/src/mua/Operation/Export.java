package src.mua.Operation;

import src.mua.Basic.BasicElement;
import src.mua.Basic.BasicOperation;
import src.mua.Support.VariableControl;

public class Export extends BasicOperation {
    public Export() {
        operandNeedCount = 1;
    }

    @Override
    public BasicElement exeResult() {
        VariableControl.getVarSL().export(BasicList.get(0).val());
        return null;
    }

    @Override
    public int elementType() {
        return 0;
    }
}
