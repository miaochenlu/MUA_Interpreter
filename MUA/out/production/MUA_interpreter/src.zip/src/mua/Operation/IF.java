package src.mua.Operation;

import src.mua.Basic.BasicElement;
import src.mua.Basic.BasicOperation;
import src.mua.COPE.Executor;
import src.mua.TYPE.BOOL;
import src.mua.TYPE.LIST;
import src.mua.TYPE.NUM;
import src.mua.TYPE.WORD;

import java.util.List;

public class IF extends BasicOperation {
    public IF() {
        operandNeedCount = 3;
    }
    @Override
    public int elementType() {
        return 0;
    }

    @Override
    public BasicElement exeResult() {
        Executor executor = new Executor();
        BOOL op1 = (BOOL)BasicList.get(0);
        LIST op2 = (LIST)BasicList.get(1);
        LIST op3 = (LIST)BasicList.get(2);
        if(op1.val().equals("true")) {
            executor.executeList(op2);
        } else if(op1.val().equals("false")) {
            executor.executeList(op3);
        }
        return null;
    }
}
