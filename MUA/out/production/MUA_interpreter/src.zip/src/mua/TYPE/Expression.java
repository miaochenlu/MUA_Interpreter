package src.mua.TYPE;

import src.mua.Basic.BasicElement;
import src.mua.COPE.Executor;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class Expression extends BasicElement {
    String Expression;
    String DelExptrssion;
    String operands = "+-*/%()";
    ArrayList<String> stringList;
    ArrayList<BasicElement> elementList;
    BasicElement res;

    public Expression(String Expr) {
        Expression = Expr;
        preDeal();
        stringList = new ArrayList<>(Arrays.asList(DelExptrssion.split("\\s+")));
        stringList.remove("");
        elementList = new ArrayList<>();
    }

    public void preDeal() {
        String res1 = new String();
        for(int i = 0; i < Expression.length();i++) {
            String substr = Expression.substring(i, i + 1);
            if(operands.contains(substr))
                res1 = res1 + " " + substr + " ";
//            else if(!substr.equals(" "))
            else
                res1 += substr;
        }
        DelExptrssion = res1;

        String res2 = new String();
        int minusAttention = 0;
        Scanner strScan = new Scanner(DelExptrssion);

        //deal with pre '-'
        while(strScan.hasNext()) {
            String readstr = strScan.next();
            if(readstr.equals("-") && minusAttention == 0)
                res2 += "0 ";
            else if(readstr.equals("("))
                minusAttention = -1;

            minusAttention++;
            res2 = res2 + readstr + " ";
        }
        DelExptrssion = res2;
        StringBuilder CodeBuilder = new StringBuilder(DelExptrssion);
        DelExptrssion = CodeBuilder.toString();
//        System.out.println(DelExptrssion);
    }

    @Override
    public int elementType() {
        return 1;
    }

    public BasicElement ExpreVal() {
        Executor executor = new Executor();
        res = executor.calculate(stringList);
        return res;
    }
    @Override
    public String val() {
        Executor executor = new Executor();
        res = executor.calculate(stringList);
        return res.val();
    }
}
