package src.mua.TYPE;

import src.mua.Basic.BasicElement;
import src.mua.Support.CodeLine;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;
import src.mua.Exception.*;
public class LIST extends BasicElement {
    ArrayList<BasicElement> listMember;
    ArrayList<String> listStrMember;
    StringBuilder listContentBuilder;
    String listContent;
    String val;

    public LIST(String Content) {
        val = Content;
        listMember = new ArrayList<BasicElement>();
        listStrMember = new ArrayList<>();
        listContentBuilder = getVal();
        split();
        _changeStr2List();
    }

    public void split() {
        StringBuilder newlistContentBuilder  = new StringBuilder(listContentBuilder);
//        CodeLine.preBlank(newlistContentBuilder);
        listStrMember= new ArrayList<>(Arrays.asList(newlistContentBuilder.toString().split("\\s+")));
        listStrMember.remove("");
        Scanner scanner = new Scanner(newlistContentBuilder.toString());
        listContent = new String();
        for(int i = 0; i < listStrMember.size(); i++){
            listContent = listContent + listStrMember.get(i) + " ";
        }
    }

    public void _changeStr2List() {
        listMember = CodeLine.changeStr2MuaELe(listStrMember);
    }

    @Override
    public int elementType() {
        return 1;
    }

    public StringBuilder getVal() {
        StringBuilder res = new StringBuilder(val);
        for(int i = 0; i < res.length(); i++) {
            if(res.charAt(i) == '[') {
                res.delete(i, i+1);
                break;
            }
        }
        for(int i = res.length() - 1; i >= 0; i--) {
            if(res.charAt(i) == ']') {
                res.delete(i, i+1);
                break;
            }
        }
        return res;
    }
    @Override
    public String val() {
        return listContentBuilder.toString();
    }

    public String valWithbracket() { return val; }

    public BasicElement getListElement(int pos) {
        return listMember.get(pos);
    }

    public void addListElement2Head(BasicElement insertElement) {
        listMember.add(0, insertElement);
    }

    public int LISTSize() {
        return listMember.size();
    }

    public ArrayList<BasicElement> ListElement(){
        return listMember;
    }
}
