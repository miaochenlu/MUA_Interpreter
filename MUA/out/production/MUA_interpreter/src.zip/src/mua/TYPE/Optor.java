//package src.src.mua.TYPE;
//import src.src.mua.Basic.BasicElement;
//import src.src.mua.Exception.DontSupportOperationException;
//import src.src.mua.Operation.OpHelper;

package src.mua.TYPE;
import src.mua.Basic.BasicElement;
import src.mua.Exception.DontSupportOperationException;
import src.mua.Operation.OpHelper;

public class Optor extends BasicElement{
    String val;
    public Optor(String initializer) {//throws DontSupportOperationException{
        OpHelper oph = new OpHelper();
        //if(oph.isOperation(initializer))
        val = initializer;
       // else
           // throw new DontSupportOperationException();
    }

    @Override
    public int elementType() {
        return 0;
    }

    @Override
    public String val() {
        return val;
    }
}
